// src/main/java/com/example/demo/service/ProductService.java
package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service // Marks this class as a Spring service component
public class ProductService {

    public String getProductDetails(String productId) {
        System.out.println("ProductService: Fetching details for product ID: " + productId);
        if ("P001".equals(productId)) {
            return "Product P001: Laptop (Price: $1200)";
        } else if ("P002".equals(productId)) {
            // Simulate an error for @AfterThrowing advice
            throw new RuntimeException("Product P002 data access error!");
        }
        return "Product not found.";
    }

    public void saveProduct(String productName, double price) {
        System.out.println("ProductService: Saving product: " + productName + " with price: " + price);
        // Simulate saving to a database
    }

    public double calculateDiscountedPrice(double originalPrice, double discountPercentage) {
        System.out.println("ProductService: Calculating discounted price.");
        return originalPrice * (1 - discountPercentage / 100);
    }
}

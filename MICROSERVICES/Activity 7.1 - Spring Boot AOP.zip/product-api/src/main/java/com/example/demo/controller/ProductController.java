package com.example.demo.controller;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService; // Import our ProductService
import org.springframework.beans.factory.annotation.Autowired; // For dependency injection
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    // In-memory "database" for demonstration purposes (from previous activity)
    private final List<Product> products = new ArrayList<>();
    private final AtomicLong counter = new AtomicLong();

    @Autowired // Inject ProductService
    private ProductService productService;

    // --- Existing CRUD methods (unchanged for this AOP demo) ---
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        product.setId(counter.incrementAndGet());
        products.add(product);
        System.out.println("Created product: " + product.getName());
        return new ResponseEntity<>(product, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        System.out.println("Fetching all products.");
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        System.out.println("Fetching product with ID: " + id);
        Optional<Product> foundProduct = products.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
        return foundProduct.map(product -> new ResponseEntity<>(product, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Product>> searchProducts(
            @RequestParam(required = false) String name,
            @RequestParam(required = false, defaultValue = "0.0") double minPrice) {

        List<Product> filteredProducts = products.stream()
                .filter(p -> (name == null || p.getName().toLowerCase().contains(name.toLowerCase())))
                .filter(p -> p.getPrice() >= minPrice)
                .collect(Collectors.toList());

        return new ResponseEntity<>(filteredProducts, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
        Optional<Product> existingProductOptional = products.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
        if (existingProductOptional.isPresent()) {
            Product existingProduct = existingProductOptional.get();
            existingProduct.setName(productDetails.getName());
            existingProduct.setPrice(productDetails.getPrice());
            return new ResponseEntity<>(existingProduct, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable Long id) {
        boolean removed = products.removeIf(p -> p.getId().equals(id));
        if (removed) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // --- New Endpoints to Demonstrate AOP ---

    // GET /api/products/aop/details/{productId}
    @GetMapping("/aop/details/{productId}")
    public ResponseEntity<String> getAopProductDetails(@PathVariable String productId) {
        System.out.println("Controller: Calling ProductService.getProductDetails for AOP demo.");
        try {
            String details = productService.getProductDetails(productId);
            return new ResponseEntity<>(details, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // POST /api/products/aop/save
    @PostMapping("/aop/save")
    public ResponseEntity<String> saveAopProduct(@RequestParam String name, @RequestParam double price) {
        System.out.println("Controller: Calling ProductService.saveProduct for AOP demo.");
        productService.saveProduct(name, price);
        return new ResponseEntity<>("Product '" + name + "' saved via AOP demo.", HttpStatus.OK);
    }

    // GET /api/products/aop/discount
    @GetMapping("/aop/discount")
    public ResponseEntity<String> getAopDiscountedPrice(@RequestParam double originalPrice, @RequestParam double discount) {
        System.out.println("Controller: Calling ProductService.calculateDiscountedPrice for AOP demo.");
        double finalPrice = productService.calculateDiscountedPrice(originalPrice, discount);
        return new ResponseEntity<>("Discounted price: " + finalPrice, HttpStatus.OK);
    }
}

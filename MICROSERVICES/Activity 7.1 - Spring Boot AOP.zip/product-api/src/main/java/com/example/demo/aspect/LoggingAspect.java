// src/main/java/com/example/demo/aspect/LoggingAspect.java
package com.example.demo.aspect;

import org.aspectj.lang.JoinPoint; // Represents a point in the execution of the program
import org.aspectj.lang.ProceedingJoinPoint; // Used specifically for @Around advice
import org.aspectj.lang.annotation.*; // AOP annotations
import org.springframework.stereotype.Component; // To make this a Spring-managed bean

@Aspect // Declares this class as an Aspect
@Component // Makes this class a Spring-managed component so Spring can discover it
public class LoggingAspect {

    // --- 1. Define a Pointcut ---
    // A Pointcut expression defines WHERE the advice should be applied.
    // This pointcut matches any public method execution in any class within
    // the 'com.example.demo.service' package (and its sub-packages if '..' was used).
    @Pointcut("execution(public * com.example.demo.service.*.*(..))")
    public void serviceMethods() {} // This method is just a placeholder for the pointcut expression

    // --- 2. Implement Different Types of Advice ---

    // @Before Advice: Executes BEFORE the target method execution.
    @Before("serviceMethods()") // Applies to the 'serviceMethods' pointcut
    public void logBefore(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName(); // Get the name of the advised method
        String args = java.util.Arrays.toString(joinPoint.getArgs()); // Get method arguments
        System.out.println("AOP @Before: Entering method '" + methodName + "' with args: " + args);
    }

    // @AfterReturning Advice: Executes AFTER the target method returns SUCCESSFULLY.
    // 'returning = "result"' binds the method's return value to the 'result' parameter.
    @AfterReturning(pointcut = "serviceMethods()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().getName();
        System.out.println("AOP @AfterReturning: Method '" + methodName + "' returned: " + result);
    }

    // @AfterThrowing Advice: Executes AFTER the target method throws an EXCEPTION.
    // 'throwing = "exception"' binds the thrown exception to the 'exception' parameter.
    @AfterThrowing(pointcut = "serviceMethods()", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable exception) {
        String methodName = joinPoint.getSignature().getName();
        System.err.println("AOP @AfterThrowing: Method '" + methodName + "' threw exception: " + exception.getMessage());
    }

    // @After Advice (Finally): Executes AFTER the target method, regardless of success or exception.
    // Similar to a 'finally' block.
    @After("serviceMethods()")
    public void logAfter(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        System.out.println("AOP @After: Method '" + methodName + "' finished execution (finally).");
    }

    // @Around Advice: Wraps the execution of the target method. Has the most control.
    // Requires a ProceedingJoinPoint to explicitly call the target method.
    @Around("serviceMethods()")
    public Object measureExecutionTime(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = null;
        try {
            result = proceedingJoinPoint.proceed(); // This calls the actual target method
        } finally {
            long endTime = System.currentTimeMillis();
            String methodName = proceedingJoinPoint.getSignature().getName();
            System.out.println("AOP @Around: Method '" + methodName + "' executed in " + (endTime - startTime) + "ms");
        }
        return result;
    }
}
